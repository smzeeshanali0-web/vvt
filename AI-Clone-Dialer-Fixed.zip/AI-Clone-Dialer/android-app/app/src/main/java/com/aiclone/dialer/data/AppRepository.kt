package com.aiclone.dialer.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.dataStore by preferencesDataStore(name = "ai_clone_dialer")

class AppRepository(private val context: Context) {
    private val accountsKey = stringPreferencesKey("sip_accounts")
    private val defaultVoiceKey = stringPreferencesKey("default_voice")
    private val aiEnabledKey = booleanPreferencesKey("ai_enabled")
    private val backendUrlKey = stringPreferencesKey("backend_url")
    private val apiKeyKey = stringPreferencesKey("backend_api_key")
    private val elevenKeyKey = stringPreferencesKey("elevenlabs_api_key")
    private val historyKey = stringPreferencesKey("call_history")
    private val activeAccountKey = stringPreferencesKey("active_account")

    val accounts: Flow<List<SipAccount>> = context.dataStore.data.map { decodeAccounts(it[accountsKey] ?: "[]") }
    val defaultVoice: Flow<String> = context.dataStore.data.map { it[defaultVoiceKey] ?: "" }
    val aiEnabled: Flow<Boolean> = context.dataStore.data.map { it[aiEnabledKey] ?: false }
    val activeAccount: Flow<String> = context.dataStore.data.map { it[activeAccountKey] ?: "" }
    val backend: Flow<BackendSettings> = context.dataStore.data.map { BackendSettings(it[backendUrlKey] ?: "", it[apiKeyKey] ?: "", it[elevenKeyKey] ?: "") }
    val history: Flow<List<CallRecord>> = context.dataStore.data.map { decodeHistory(it[historyKey] ?: "[]") }

    suspend fun saveAccount(account: SipAccount) {
        context.dataStore.edit { prefs ->
            val list = decodeAccounts(prefs[accountsKey] ?: "[]").toMutableList()
            val idx = list.indexOfFirst { it.id == account.id }
            if (idx >= 0) list[idx] = account else list.add(account)
            prefs[accountsKey] = encodeAccounts(list)
        }
    }
    suspend fun deleteAccount(id: String) {
        context.dataStore.edit { prefs ->
            prefs[accountsKey] = encodeAccounts(decodeAccounts(prefs[accountsKey] ?: "[]").filter { it.id != id })
        }
    }
    suspend fun setActiveAccount(id: String) { context.dataStore.edit { it[activeAccountKey] = id } }
    suspend fun setDefaultVoice(id: String) { context.dataStore.edit { it[defaultVoiceKey] = id } }
    suspend fun setAiEnabled(enabled: Boolean) { context.dataStore.edit { it[aiEnabledKey] = enabled } }
    suspend fun saveBackend(s: BackendSettings) {
        context.dataStore.edit { it[backendUrlKey] = s.url.trim(); it[apiKeyKey] = s.apiKey.trim(); it[elevenKeyKey] = s.elevenKey.trim() }
    }
    suspend fun addHistory(r: CallRecord) {
        context.dataStore.edit { prefs ->
            val list = (listOf(r) + decodeHistory(prefs[historyKey] ?: "[]")).take(200)
            prefs[historyKey] = JSONArray().apply {
                list.forEach { h -> put(JSONObject().apply {
                    put("id", h.id); put("number", h.number); put("startedAt", h.startedAt)
                    put("seconds", h.seconds); put("aiVoice", h.aiVoice); put("result", h.result)
                }) }
            }.toString()
        }
    }
    suspend fun clearHistory() { context.dataStore.edit { it[historyKey] = "[]" } }

    private fun decodeHistory(raw: String): List<CallRecord> = runCatching {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            CallRecord(o.optString("id"), o.optString("number"), o.optLong("startedAt"), o.optInt("seconds"),
                o.optBoolean("aiVoice"), o.optString("result"))
        }
    }.getOrDefault(emptyList())

    private fun encodeAccounts(items: List<SipAccount>) = JSONArray().apply {
        items.forEach { a -> put(JSONObject().apply {
            put("id", a.id); put("label", a.label); put("username", a.username); put("password", a.password)
            put("server", a.server); put("domain", a.domain); put("ipAddress", a.ipAddress); put("port", a.port)
            put("proxy", a.proxy); put("authId", a.authId); put("callerId", a.callerId)
            put("displayName", a.displayName); put("transport", a.transport); put("stun", a.stun); put("enabled", a.enabled)
        }) }
    }.toString()

    private fun decodeAccounts(raw: String): List<SipAccount> = runCatching {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            SipAccount(id = o.optString("id"), label = o.optString("label"), username = o.optString("username"),
                password = o.optString("password"), server = o.optString("server"), domain = o.optString("domain"),
                ipAddress = o.optString("ipAddress"), port = o.optInt("port", 5060), proxy = o.optString("proxy"),
                authId = o.optString("authId"), callerId = o.optString("callerId"), displayName = o.optString("displayName"),
                transport = o.optString("transport", "UDP"), stun = o.optString("stun"), enabled = o.optBoolean("enabled", true))
        }
    }.getOrDefault(emptyList())
}
