package com.aiclone.dialer

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.aiclone.dialer.call.CallClient
import com.aiclone.dialer.data.*
import com.aiclone.dialer.net.BackendClient
import com.aiclone.dialer.net.BackendException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repository = AppRepository(applicationContext)
        val callClient = CallClient(applicationContext, lifecycleScope)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { DialerApp(repository, callClient) } }
    }
}

private fun toast(c: Context, m: String) = Toast.makeText(c, m, Toast.LENGTH_LONG).show()
private fun fmt(sec: Int) = "%02d:%02d".format(sec / 60, sec % 60)

private fun readPicked(c: Context, uri: Uri): Triple<String, ByteArray, String> {
    var name = "voice.mp3"
    c.contentResolver.query(uri, null, null, null, null)?.use {
        if (it.moveToFirst()) { val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) name = it.getString(i) }
    }
    val bytes = c.contentResolver.openInputStream(uri)?.use { s -> s.readBytes() } ?: ByteArray(0)
    return Triple(name, bytes, c.contentResolver.getType(uri) ?: "audio/mpeg")
}

private data class Pending(val id: String, val ownerName: String, val relation: String, val text: String)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun DialerApp(repo: AppRepository, calls: CallClient) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val accounts by repo.accounts.collectAsState(emptyList())
    val defaultVoice by repo.defaultVoice.collectAsState("")
    val aiEnabled by repo.aiEnabled.collectAsState(false)
    val activeAccount by repo.activeAccount.collectAsState("")
    val backendSettings by repo.backend.collectAsState(BackendSettings())
    val history by repo.history.collectAsState(emptyList())
    val callUi by calls.ui.collectAsState()
    val backend = remember(backendSettings) { BackendClient(backendSettings.url, backendSettings.apiKey, backendSettings.elevenKey) }

    var tab by remember { mutableStateOf("Dialer") }
    var number by remember { mutableStateOf("") }
    var profiles by remember { mutableStateOf(emptyList<VoiceProfile>()) }
    var busy by remember { mutableStateOf("") }
    var editAccount by remember { mutableStateOf<SipAccount?>(null) }
    var showAccountDialog by remember { mutableStateOf(false) }
    var showAddVoice by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf<Pending?>(null) }
    var confirmAi by remember { mutableStateOf(false) }
    var wantCall by remember { mutableStateOf(false) }

    fun <T> guarded(label: String, block: suspend () -> T, done: (T) -> Unit = {}) {
        scope.launch {
            busy = label
            try { done(block()) } catch (e: BackendException) { toast(ctx, e.message ?: "Error") }
            catch (e: Exception) { toast(ctx, "Error: ${e.message}") }
            busy = ""
        }
    }
    fun refresh() = guarded("Refreshing voices…", { backend.profiles() }, { profiles = it })

    LaunchedEffect(backendSettings) { if (backendSettings.url.isNotBlank()) runCatching { profiles = backend.profiles() } }

    fun reallyCall() {
        val account = accounts.firstOrNull { it.id == activeAccount && it.enabled } ?: accounts.firstOrNull { it.enabled }
        if (account == null) { toast(ctx, "Add and enable a SIP account first"); return }
        if (backendSettings.url.isBlank()) { toast(ctx, "Set the backend URL in Settings"); return }
        val useAi = aiEnabled
        val voice = profiles.firstOrNull { it.id == defaultVoice && it.status == "ready" }
        if (useAi && voice == null) { toast(ctx, "AI voice is ON but no ready voice is selected. Pick one in Voice Studio or turn AI voice off."); return }
        calls.start(backend, account, number.trim(), voice?.id) { rec -> scope.launch { repo.addHistory(rec) } }
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted && wantCall) { wantCall = false; if (aiEnabled) confirmAi = true else reallyCall() } else if (!granted) toast(ctx, "Microphone permission is required for calls")
    }
    fun placeCall() {
        if (number.isBlank()) { toast(ctx, "Enter a destination number"); return }
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            wantCall = true; micPermission.launch(Manifest.permission.RECORD_AUDIO); return
        }
        if (aiEnabled) confirmAi = true else reallyCall()
    }

    if (callUi.state != "idle") { CallScreen(calls, callUi); return }

    Scaffold(
        topBar = { TopAppBar(title = { Text("AI Clone Dialer") }) },
        bottomBar = {
            NavigationBar {
                listOf("Dialer", "History", "Accounts", "Voice Studio", "Settings").forEach { item ->
                    NavigationBarItem(selected = tab == item, onClick = { tab = item }, label = { Text(item, maxLines = 1) }, icon = {
                        Icon(when (item) {
                            "Dialer" -> Icons.Default.Dialpad; "History" -> Icons.Default.History
                            "Accounts" -> Icons.Default.AccountCircle; "Voice Studio" -> Icons.Default.GraphicEq
                            else -> Icons.Default.Settings }, item)
                    })
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            if (busy.isNotEmpty()) { LinearProgressIndicator(Modifier.fillMaxWidth()); Text(busy, style = MaterialTheme.typography.bodySmall) }
            when (tab) {
                "Dialer" -> {
                    val acc = accounts.firstOrNull { it.id == activeAccount && it.enabled } ?: accounts.firstOrNull { it.enabled }
                    Text("Account: ${acc?.label ?: "none — add one in Accounts"}", style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(number, { number = it }, label = { Text("Phone number / SIP URI") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "*", "0", "#").chunked(3).forEach { row ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            row.forEach { k -> OutlinedButton({ number += k }, Modifier.weight(1f).height(54.dp)) { Text(k) } }
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button({ placeCall() }, Modifier.weight(1f)) { Icon(Icons.Default.Call, null); Spacer(Modifier.width(6.dp)); Text("Call") }
                        OutlinedButton({ number = number.dropLast(1) }) { Icon(Icons.Default.Backspace, "Delete") }
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Use AI cloned voice on this call")
                            Text(profiles.firstOrNull { it.id == defaultVoice }?.let { "Voice: ${it.name} (${it.status})" } ?: "No voice selected",
                                style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(aiEnabled, { scope.launch { repo.setAiEnabled(it) } })
                    }
                    Text("If AI voice is ON and conversion is unavailable, the other party hears silence — never your real voice.", style = MaterialTheme.typography.bodySmall)
                }
                "History" -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Recent calls", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                        TextButton({ scope.launch { repo.clearHistory() } }) { Text("Clear") }
                    }
                    LazyColumn { items(history) { h ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(h.number, style = MaterialTheme.typography.titleMedium)
                                    Text("${SimpleDateFormat("dd MMM HH:mm", Locale.getDefault()).format(Date(h.startedAt))} · ${fmt(h.seconds)} · ${if (h.aiVoice) "AI voice" else "own voice"} · ${h.result}", style = MaterialTheme.typography.bodySmall)
                                }
                                IconButton({ number = h.number; tab = "Dialer" }) { Icon(Icons.Default.Call, "Redial") }
                            }
                        }
                    } }
                }
                "Accounts" -> {
                    Text("SIP accounts", style = MaterialTheme.typography.titleLarge)
                    Button({ editAccount = null; showAccountDialog = true }) { Text("Add SIP account") }
                    LazyColumn { items(accounts) { a ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                            Column(Modifier.padding(12.dp)) {
                                Text(a.label + if (a.id == activeAccount) "  ✓ active" else "", style = MaterialTheme.typography.titleMedium)
                                Text("${a.username}@${a.server}:${a.port} (${a.transport})")
                                if (a.transport != "UDP") Text("Gateway supports UDP only for now", style = MaterialTheme.typography.bodySmall)
                                Row {
                                    TextButton({ scope.launch { repo.setActiveAccount(a.id) } }) { Text("Use") }
                                    TextButton({ editAccount = a; showAccountDialog = true }) { Text("Edit") }
                                    TextButton({ scope.launch { repo.deleteAccount(a.id) } }) { Text("Delete") }
                                }
                            }
                        }
                    } }
                }
                "Voice Studio" -> {
                    Text("Voice Studio", style = MaterialTheme.typography.titleLarge)
                    Text("Upload an MP3 of YOUR voice (or someone who gave you permission). Nothing is cloned until the voice owner accepts the consent screen.", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button({ showAddVoice = true }) { Text("Add voice") }
                        OutlinedButton({ refresh() }) { Text("Refresh") }
                    }
                    LazyColumn { items(profiles) { v ->
                        Card(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                            Column(Modifier.padding(12.dp)) {
                                Text(v.name + if (v.id == defaultVoice) "  ★ default" else "", style = MaterialTheme.typography.titleMedium)
                                Text("Owner: ${v.ownerName} · ${v.status}")
                                if (v.error.isNotBlank()) Text(v.error, style = MaterialTheme.typography.bodySmall)
                                Row {
                                    when (v.status) {
                                        "awaiting_consent" -> TextButton({
                                            guarded("Loading consent…", { backend.consentText() }, { t -> pending = Pending(v.id, v.ownerName, v.ownerRelation, t) })
                                        }) { Text("Review consent") }
                                        "consented", "failed" -> TextButton({
                                            guarded("Creating clone… (can take a minute)", { backend.clone(v.id); backend.profiles() }, { profiles = it })
                                        }) { Text("Create clone") }
                                        "ready" -> TextButton({ scope.launch { repo.setDefaultVoice(v.id) } }) { Text("Set default") }
                                    }
                                    TextButton({ guarded("Deleting…", { backend.delete(v.id); backend.profiles() }, { profiles = it; if (defaultVoice == v.id) scope.launch { repo.setDefaultVoice("") } }) }) { Text("Delete / revoke") }
                                }
                            }
                        }
                    } }
                }
                else -> SettingsTab(repo, backendSettings, backend, ctx)
            }
        }
    }

    if (showAccountDialog) SipAccountDialog(editAccount, { showAccountDialog = false }, { a ->
        scope.launch { repo.saveAccount(a); if (activeAccount.isEmpty()) repo.setActiveAccount(a.id) }; showAccountDialog = false
    })
    if (showAddVoice) AddVoiceDialog({ showAddVoice = false }) { name, owner, relation, picked ->
        showAddVoice = false
        guarded("Uploading sample…", { backend.createProfile(name, owner, relation, picked.first, picked.second, picked.third) },
            { (id, text) -> pending = Pending(id, owner, relation, text); refresh() })
    }
    pending?.let { p ->
        ConsentDialog(p, onDismiss = { pending = null; refresh() }) { accept, ack, typed, note ->
            pending = null
            guarded(if (accept) "Saving consent and cloning…" else "Declining…", {
                val st = backend.respondConsent(p.id, accept, ack, typed, note)
                if (accept && st == "consented") backend.clone(p.id)
                st
            }, { st -> toast(ctx, if (st == "declined") "Declined — nothing was cloned and the sample was deleted." else "Voice clone ready"); refresh() })
        }
    }
    if (confirmAi) AlertDialog(
        onDismissRequest = { confirmAi = false }, title = { Text("Start call with AI voice?") },
        text = { Text("The other person will hear an AI-generated voice. Tell them the voice is AI-generated where the law or your provider requires it. Do not impersonate anyone to deceive them.") },
        confirmButton = { TextButton({ confirmAi = false; reallyCall() }) { Text("I understand — call") } },
        dismissButton = { TextButton({ confirmAi = false }) { Text("Cancel") } })
}

@Composable
private fun SettingsTab(repo: AppRepository, s: BackendSettings, backend: BackendClient, ctx: Context) {
    val scope = rememberCoroutineScope()
    var url by remember(s) { mutableStateOf(s.url) }
    var key by remember(s) { mutableStateOf(s.apiKey) }
    var eleven by remember(s) { mutableStateOf(s.elevenKey) }
    var result by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Backend", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(url, { url = it }, label = { Text("Backend URL (https://… or http://ip:8000)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(key, { key = it }, label = { Text("API key") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(eleven, { eleven = it }, label = { Text("ElevenLabs API key (for voice clone)") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ scope.launch { repo.saveBackend(BackendSettings(url, key, eleven)); toast(ctx, "Saved") } }) { Text("Save") }
            OutlinedButton({
                scope.launch {
                    repo.saveBackend(BackendSettings(url, key, eleven))
                    result = try { val h = BackendClient(url, key, eleven).health(); "OK · voice provider: ${h.optString("voice_provider", "none")}" } catch (e: Exception) { "Failed: ${e.message}" }
                }
            }) { Text("Test connection") }
        }
        if (result.isNotEmpty()) Text(result)
        Text("ElevenLabs key is sent only to YOUR backend (use HTTPS) and used for clone + live voice conversion. SIP calls and AI voice run on your backend (see ai-backend/). Use HTTPS in production. SIP passwords are stored in app preferences in this build.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun CallScreen(calls: CallClient, ui: com.aiclone.dialer.call.CallUi) {
    var showKeys by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(ui.number, style = MaterialTheme.typography.headlineMedium)
        Text(when (ui.state) { "connected" -> fmt(ui.seconds); "ended" -> "Call ended: ${ui.detail}"; else -> ui.state.replaceFirstChar { it.uppercase() } + "…" })
        if (ui.aiVoice) Text("AI voice active — the other party hears a cloned voice", style = MaterialTheme.typography.bodySmall)
        if (ui.message.isNotBlank()) Text(ui.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(24.dp))
        if (ui.state == "ended") { Button({ calls.reset() }) { Text("Close") }; return@Column }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            FilledTonalButton({ calls.setMuted(!ui.muted) }) { Icon(if (ui.muted) Icons.Default.MicOff else Icons.Default.Mic, "Mute"); Spacer(Modifier.width(4.dp)); Text(if (ui.muted) "Unmute" else "Mute") }
            FilledTonalButton({ calls.setSpeaker(!ui.speaker) }) { Icon(Icons.Default.VolumeUp, "Speaker"); Spacer(Modifier.width(4.dp)); Text(if (ui.speaker) "Earpiece" else "Speaker") }
            FilledTonalButton({ showKeys = !showKeys }) { Icon(Icons.Default.Dialpad, "Keypad") }
        }
        if (showKeys) {
            Spacer(Modifier.height(12.dp))
            listOf("123", "456", "789", "*0#").forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { row.forEach { k -> OutlinedButton({ calls.dtmf(k) }) { Text(k.toString()) } } }
            }
        }
        Spacer(Modifier.height(24.dp))
        Button({ calls.hangup() }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) {
            Icon(Icons.Default.CallEnd, "Hang up"); Spacer(Modifier.width(6.dp)); Text("Hang up")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SipAccountDialog(existing: SipAccount?, onDismiss: () -> Unit, onSave: (SipAccount) -> Unit) {
    var label by remember { mutableStateOf(existing?.label ?: "My SIP") }
    var username by remember { mutableStateOf(existing?.username ?: "") }
    var password by remember { mutableStateOf(existing?.password ?: "") }
    var server by remember { mutableStateOf(existing?.server ?: "") }
    var domain by remember { mutableStateOf(existing?.domain ?: "") }
    var proxy by remember { mutableStateOf(existing?.proxy ?: "") }
    var authId by remember { mutableStateOf(existing?.authId ?: "") }
    var callerId by remember { mutableStateOf(existing?.callerId ?: "") }
    var displayName by remember { mutableStateOf(existing?.displayName ?: "") }
    var port by remember { mutableStateOf((existing?.port ?: 5060).toString()) }
    var transport by remember { mutableStateOf(existing?.transport ?: "UDP") }
    var enabled by remember { mutableStateOf(existing?.enabled ?: true) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (existing == null) "Add SIP account" else "Edit SIP account") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                item { SipField("Account name", label) { label = it } }
                item { SipField("SIP username", username) { username = it } }
                item { OutlinedTextField(password, { password = it }, label = { Text("SIP password") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth()) }
                item { SipField("SIP server / IP", server) { server = it } }
                item { SipField("Port", port) { port = it } }
                item { SipField("SIP domain (optional)", domain) { domain = it } }
                item { SipField("Outbound proxy (optional)", proxy) { proxy = it } }
                item { SipField("Authentication ID (optional)", authId) { authId = it } }
                item { SipField("Caller ID (optional)", callerId) { callerId = it } }
                item { SipField("Display name (optional)", displayName) { displayName = it } }
                item {
                    var expanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(expanded, { expanded = it }) {
                        OutlinedTextField(transport, {}, readOnly = true, label = { Text("Transport") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                        ExposedDropdownMenu(expanded, { expanded = false }) {
                            listOf("UDP", "TCP", "TLS").forEach { DropdownMenuItem(text = { Text(it) }, onClick = { transport = it; expanded = false }) }
                        }
                    }
                }
                item { Row(verticalAlignment = Alignment.CenterVertically) { Text("Enabled", Modifier.weight(1f)); Switch(enabled, { enabled = it }) } }
            }
        },
        confirmButton = {
            TextButton({
                if (username.isNotBlank() && server.isNotBlank()) onSave(SipAccount(id = existing?.id ?: UUID.randomUUID().toString(), label = label, username = username,
                    password = password, server = server, domain = domain, port = port.toIntOrNull() ?: 5060, proxy = proxy, authId = authId,
                    callerId = callerId, displayName = displayName, transport = transport, enabled = enabled))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } })
}

@Composable
private fun SipField(label: String, value: String, onValue: (String) -> Unit) =
    OutlinedTextField(value, onValue, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddVoiceDialog(onDismiss: () -> Unit, onUpload: (String, String, String, Triple<String, ByteArray, String>) -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }
    var owner by remember { mutableStateOf("") }
    var relation by remember { mutableStateOf("self") }
    var picked by remember { mutableStateOf<Triple<String, ByteArray, String>?>(null) }
    val scope = rememberCoroutineScope()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch { picked = withContext(Dispatchers.IO) { readPicked(ctx, uri) } }
    }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Add voice") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Profile name") }, singleLine = true)
                OutlinedTextField(owner, { owner = it }, label = { Text("Voice owner's full name") }, singleLine = true)
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded, { expanded = it }) {
                    OutlinedTextField(if (relation == "self") "This is my own voice" else "Someone else (with their permission)", {}, readOnly = true,
                        label = { Text("Whose voice?") }, modifier = Modifier.menuAnchor().fillMaxWidth())
                    ExposedDropdownMenu(expanded, { expanded = false }) {
                        DropdownMenuItem(text = { Text("This is my own voice") }, onClick = { relation = "self"; expanded = false })
                        DropdownMenuItem(text = { Text("Someone else (with their permission)") }, onClick = { relation = "other_with_permission"; expanded = false })
                    }
                }
                OutlinedButton({ picker.launch(arrayOf("audio/*")) }) { Text(picked?.let { "${it.first} (${it.second.size / 1024} KB)" } ?: "Choose MP3 / WAV / M4A") }
                Text("Use 1–3 minutes of clean speech. You will see the consent screen next; nothing is cloned until the owner accepts.", style = MaterialTheme.typography.bodySmall)
            }
        },
        confirmButton = { TextButton({ val p = picked; if (name.isNotBlank() && owner.isNotBlank() && p != null) onUpload(name, owner, relation, p) }) { Text("Continue") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } })
}

@Composable
private fun ConsentDialog(p: Pending, onDismiss: () -> Unit, onDecision: (Boolean, Boolean, String, String) -> Unit) {
    var ack by remember { mutableStateOf(false) }
    var typed by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Voice cloning consent") },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item { Text(p.text) }
                item { Row(verticalAlignment = Alignment.CenterVertically) { Checkbox(ack, { ack = it }); Text("I understand the other party must be told the voice is AI-generated where required.", Modifier.weight(1f)) } }
                item { OutlinedTextField(typed, { typed = it }, label = { Text("Type the voice owner's name: ${p.ownerName}") }, singleLine = true, modifier = Modifier.fillMaxWidth()) }
                if (p.relation != "self") item { OutlinedTextField(note, { note = it }, label = { Text("How/when did they give permission?") }, modifier = Modifier.fillMaxWidth()) }
            }
        },
        confirmButton = { TextButton({ onDecision(true, ack, typed, note) }, enabled = ack && typed.isNotBlank()) { Text("Accept & clone") } },
        dismissButton = { TextButton({ onDecision(false, false, "", "") }) { Text("Decline (delete)") } })
}
